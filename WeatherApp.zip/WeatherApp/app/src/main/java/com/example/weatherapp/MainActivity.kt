package com.example.weatherapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.squareup.moshi.JsonDataException
import com.squareup.moshi.Moshi
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var locationEnter: EditText
    private lateinit var weatherText: TextView
    private lateinit var button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button = findViewById(R.id.button)
        weatherText = findViewById(R.id.weather)
        locationEnter = findViewById(R.id.location)
        fun parseWeatherJson(json: String): Weather {
            val moshi = Moshi.Builder().build()
            val adapter = moshi.adapter(Weather::class.java)
            return adapter.fromJson(json) ?: throw JsonDataException("Invalid JSON format")
        }

        fun updateWeatherUI(weather: Weather) {
            val temperatureText = getString(R.string.temperature.toInt(), weather.temperature)
            val humidityText = getString(R.string.humidity.toInt(), weather.humidity)
            val descriptionText = getString(R.string.description.toInt(), weather.description)
            val iconUrl = "https://openweathermap.org/img/w/${weather.icon}.png"

            weatherText.text = "$temperatureText\n$humidityText\n$descriptionText"

        }

        fun fetchWeather(location: String){
            val apiKey = "ea7d29da411bfde436d6ee7effcda969"
            val url = "https://api.openweathermap.org/data/2.5/weather?q=$location&appid=$apiKey"
            val request = Request.Builder().url(url).build()
            val client = OkHttpClient()
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Network error occurred", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    val json = response.body?.string()
                    if (response.isSuccessful && json != null) {
                        val weather = parseWeatherJson(json)
                        runOnUiThread {
                            updateWeatherUI(weather)
                        }
                    } else {
                        // Handle API errors
                    }
                }
            })

        }


        button.setOnClickListener{
            val location = locationEnter.text.toString()
            fetchWeather(location)
        }

    }
}