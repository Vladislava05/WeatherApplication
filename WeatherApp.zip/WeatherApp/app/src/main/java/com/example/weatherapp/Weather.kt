package com.example.weatherapp

data class Weather(
    val temperature: Double,
    val humidity: Int,
    val description: String,
    val icon: String
)
